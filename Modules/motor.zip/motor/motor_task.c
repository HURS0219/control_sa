#include "motor_task.h"

#include "dji_motor.h"
#include "servo_motor.h"
#include "dart_app.h"
#include "st7735_ui.h"

volatile uint32_t g_motor_loops;

void MotorControlTask() {
  g_motor_loops++;
  /* [临时] 电机测试期间屏蔽飞镖制导与显示任务 */
  /* DartAppTask(); */
  /* ST7735_UI_Task(); */

  DJIMotorTask();

  /* 如果有对应的电机则取消注释,可以加入条件编译或者register对应的idx判断是否注册了电机 */
}
