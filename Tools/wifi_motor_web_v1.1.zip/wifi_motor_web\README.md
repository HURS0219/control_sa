# WiFi 电机网页控制 / 调参 标准应用 (wifi_motor_web v1.0)

用 **ESP32 (MicroPython)** 做 WiFi 热点 + 网页，手机浏览器即可控制 / 调参任意电机。
网页端**电机无关**，只认一套通用协议；具体电机由 STM32 端实现。
已在 **GM6020** 上验证，可用于 M3508 / M2006 等（需 STM32 端适配驱动）。

---

## 1. 架构

```
手机网页  --WiFi-->  ESP32(网页+协议)  --UART-->  STM32(电机驱动)  --CAN-->  电机
```

- **ESP32**：跑本应用 `main.py`，提供网页、HTTP、串口协议、掉电保存。
- **STM32**：跑一个实现下面「通用协议」的 app（如 `UserApp/robot/wifi_gm6020`）。
- 两者用 **UART** 连接（默认 115200 8N1）。

---

## 2. 硬件连接

| ESP32 | STM32 (F407 C板) |
|---|---|
| GPIO17 (TX) | PG9  (USART6_RX) |
| GPIO18 (RX) | PG14 (USART6_TX) |
| GND | GND (必须共地) |

电机接 STM32 的 CAN（注意：**CANH↔CANH、CANL↔CANL**，两端 **120Ω 终端电阻**，电机要接 **24V 动力电**）。

---

## 3. 烧录

### STM32
```
cmake -G Ninja -S . -B cmake-build-wifi_gm6020 -DROBOT_TYPE=wifi_gm6020
cmake --build cmake-build-wifi_gm6020
# 用 JLink/OpenOCD 烧 cmake-build-wifi_gm6020/control-2026.hex
```

### ESP32 (MicroPython)
1. 首次烧 MicroPython 固件（YD-ESP32-S3-N8R8 用官方/厂商 bin，`esptool` 写 0x0）；
2. 上传本应用：
```
python -m mpremote connect COM6 fs cp main.py :main.py
python -m mpremote connect COM6 reset
```

---

## 4. 使用（手机）

1. 连 WiFi：默认 `MOTOR_CTRL` / `12345678`（可在配置区改）；
2. 浏览器打开 `http://192.168.4.1`；
3. **停止 / 速度 / 角度** 三个模式，拖滑块控制；
4. 顶部显示**实际转速**（来自 STM32 反馈）；
5. **限幅** 输入框可随时改（限制输出上限）；
6. **复位(设零)** 把电机当前方向设为角度模式 0°；
7. **PID 调参区只在“停止”状态显示**（点“停止”出现），改完点“应用参数”；
8. **电机识别**（停止时）：点“扫描电机”，列出总线上的电机（反馈帧 ID），
   自动推断类型；有歧义时下拉选择类型/ID，点“应用”即可（改类型/ID 也会掉电保存）。

> 安全：网页失联 1.5s 自动停车（ESP32）；STM32 另有 1s 指令超时看门狗。
>
> 扫描为**事件驱动**（无新任务）：仅点击后、且在停止状态，才在现有任务里跑 500ms，平时零开销。
> 说明：反馈帧 ID `0x201~0x204` 分不出 M3508/M2006，`0x205~0x208` 分不出 GM6020/M3508/M2006，
> 故扫描只负责**找到 ID**，类型由你确认（下拉默认给启发式建议）。

---

## 5. 通用协议

**ESP32 → STM32**（ASCII，`\n` 结尾）

| 帧 | 含义 |
|---|---|
| `C,<mode>,<value>` | 控制。mode: 0 停 / 1 速度 / 2 角度；value: 速度=RPM，角度=角度×10 |
| `P,<id>,<value>` | 设参数（浮点参数 ×100 传入） |
| `Z` | 设零（当前方向 = 角度 0°） |
| `S` | 扫描电机（识别总线上的电机） |
| `M,<type>,<id>` | 设置电机类型/ID（0=GM6020,1=M3508,2=M2006） |
| `PING` | 链路自检，STM32 回 `PONG` |

**STM32 → ESP32**

```
F,<mode>,<rpm>,<p1>,<p2>,...,<limit>,<zero>,<type>,<id>
S,<n>,<fb_id1>,...            # 扫描结果(反馈帧 ID)
```
- `p1..pn`：`PARAMS` 表中各参数的当前值（按表顺序）
- `limit`：限幅；`zero`：零点（×100）；`type/id`：当前电机类型与 ID

> 帧间隔建议 ≥20ms，否则空闲中断收包会粘连（ESP32 上电恢复已加 30ms 间隔）。

---

## 6. 配置区（`main.py` 顶部）

```python
AP_SSID = "MOTOR_CTRL"
AP_PASS = "12345678"
MAX_RPM = 120      # 速度滑块量程
MAX_ANGLE = 180    # 角度滑块量程

# (id, 显示名, 缩放系数, 输入步长)   id 必须与 STM32 端一致
PARAMS = [
    (1, "速度前馈 FF", 100, 0.1),
    (2, "速度 Kp", 100, 0.1),
    ...
]
LIMIT_ID = 6   # 限幅参数 id
ZERO_ID = 9    # 零点参数 id
```
网页 UI 会**根据 `PARAMS` 自动生成**，换电机一般只改这里。

---

## 7. 掉电保存

- **STM32**：零点 + 全部参数存内部 Flash（sector11）；改动后置脏标记，**停止时**写入；上电恢复。
- **ESP32**：存 `cfg.txt`；上电下发给 STM32；停止且参数变化时限频保存。
- 想清零：删 `cfg.txt`（`mpremote connect COM6 fs rm :cfg.txt`）并擦 STM32 对应扇区 / 重烧。

---

## 8. 换电机（M3508 / M2006）

`simple_motor` 已是**通用驱动**，支持 GM6020 / M3508 / M2006，换电机只改一处：

```c
// UserApp/robot/wifi_gm6020/robot_config.h
#define SIMPLE_MOTOR_TYPE SIMPLE_MOTOR_GM6020   // 改成 _M3508 / _M2006
#define SIMPLE_MOTOR_ID   2                      // 电调拨码 ID
```
驱动会按类型自动选择控制帧 ID、反馈帧 ID 和输出限幅。

| 电机 | 控制帧(ID1-4 / ID5-8) | 数值范围 | 反馈帧 |
|---|---|---|---|
| GM6020 | `0x1FF` / `0x2FF` | ±30000 | `0x204+id` |
| M3508 | `0x200` / `0x1FF` | ±16384 | `0x200+id` |
| M2006 | `0x200` / `0x1FF` | ±10000 | `0x200+id` |

- 控制帧 8 字节 = 4 电机 × 2 字节（大端 int16），按 `(id-1)%4` 定位槽位；
- 注意 **GM6020 与 M3508/M2006 的控制帧 ID 会冲突**，混用时注意 ID 分配；
- ESP32 端按需修改 `PARAMS` 和量程（`MAX_RPM/MAX_ANGLE`）。

---

## 9. 常见问题

- **电机不转**：先看 CAN —— 若 STM32 的 CAN `ESR` 报 `BOFF/TEC` 上升，说明**没有节点应答**：检查电机是否上电(24V)、是否接在正确 CAN 口、H/L 是否接反、终端电阻、共地。
- **网页打不开**：确认连的是本应用的热点；地址用 `http://192.168.4.1`（带 `http://`）；手机别自动切到移动数据。
- **延迟大**：确保只开一个页面；本应用单页单轮询，已优化。
- **角度模式太猛**：调小 `角度斜率` 或 `角度Kp`，增大 `角度Kd`。

---

## 10. 文件

```
Tools/wifi_motor_web/
  main.py      # 标准应用(ESP32/MicroPython)
  README.md    # 本文件

UserApp/robot/wifi_gm6020/          # 配套 STM32 app (GM6020)
  robot.c / robot_config.h          # 入口 + 参数默认值
  wifi_motor.c/.h                   # 模式控制(速度PI+FF / 角度PD+斜率)
  wifi_link.c/.h                    # 串口协议解析
  wifi_store.c/.h                   # 掉电保存
  simple_motor.c/.h                 # 最简 CAN 驱动
  esp32/main.py                     # 同标准应用
  esp32/tools/                      # 调试脚本
```
