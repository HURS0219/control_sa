# main.py — WiFi 电机调参/控制 标准网页应用 (ESP32-S3 / MicroPython)
# 版本: wifi_motor_web v1.1
#
# 电机无关: 只认下面这套“通用协议”, 具体电机由 STM32 端实现。
#   ESP32 -> STM32:  C,<mode>,<value>   控制 (0停/1速度RPM/2角度deg*10)
#                    P,<id>,<value>     设参数 (浮点 x100)
#                    Z                  设零
#                    S                  扫描电机(识别总线上的电机)
#                    M,<type>,<id>      设置电机类型/ID (0=GM6020,1=M3508,2=M2006)
#                    PING               自检
#   STM32 -> ESP32:  F,<mode>,<rpm>,<p1..pn>,<limit>,<zero>,<type>,<id>
#                    S,<n>,<fb_id1>,... 扫描结果(反馈帧 ID)
#
# 换电机: 改下面【配置区】即可。
# 手机: 连 WiFi -> http://192.168.4.1

import network
import socket
import time
from machine import UART

# ======================== 配置区 ========================
AP_SSID = "MOTOR_CTRL"
AP_PASS = "12345678"
UART_ID = 1
UART_TX = 17
UART_RX = 18
BAUD = 115200

MAX_RPM = 120
MAX_ANGLE = 180

PARAMS = [
    (1, "速度前馈 FF", 100, 0.1),
    (2, "速度 Kp", 100, 0.1),
    (3, "速度 Ki", 100, 0.1),
    (4, "积分限幅 I-limit", 100, 1),
    (5, "角度 Kp", 100, 1),
    (7, "角度 Kd(阻尼)", 100, 1),
    (8, "角度斜率", 100, 1),
]
LIMIT_ID = 6
ZERO_ID = 9

TYPE_NAMES = ["GM6020", "M3508", "M2006"]
# =======================================================

CFG_FILE = "cfg.txt"
NP = len(PARAMS)
LIM_IDX = 2 + NP
ZERO_IDX = 3 + NP
TYPE_IDX = 4 + NP
ID_IDX = 5 + NP
STATE_LEN = NP + 6
IDX = {pid: 2 + i for i, (pid, _, _, _) in enumerate(PARAMS)}
IDX[LIMIT_ID] = LIM_IDX
IDX[ZERO_ID] = ZERO_IDX
CFG_IDS = sorted(IDX.keys())

_tune_rows = "".join(
    '<div class="row"><label>%s</label><input id="p%d" type="number" step="%s"></div>' % (lab, pid, step)
    for (pid, lab, sc, step) in PARAMS
)
_js_params = ",".join("[%d,%d]" % (pid, sc) for (pid, lab, sc, step) in PARAMS)

PAGE = """<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
<title>电机控制</title>
<style>
  body{font-family:-apple-system,Roboto,sans-serif;background:#111;color:#eee;margin:0;padding:20px;text-align:center}
  h2{margin:8px 0 20px}
  .modes{display:flex;gap:10px;justify-content:center;margin-bottom:24px}
  .modes button{flex:1;max-width:120px;padding:14px 0;font-size:16px;border:1px solid #444;border-radius:12px;background:#222;color:#ddd}
  .modes button.on{background:#2d7dff;border-color:#2d7dff;color:#fff}
  .val{font-size:44px;font-weight:700;margin:10px 0 4px;min-height:52px}
  .actual{color:#2d7dff;font-size:18px;margin-bottom:6px}
  input[type=range]{width:92%;height:44px;accent-color:#2d7dff;margin-top:10px}
  .hint{color:#888;margin-top:14px;font-size:14px}
  .lim{margin-top:18px;color:#bbb}
  .lim input{width:100px;padding:8px;font-size:16px;border-radius:8px;border:1px solid #444;background:#222;color:#fff;text-align:right}
  .lim button{padding:8px 14px;font-size:15px;border:none;border-radius:8px;background:#2d7dff;color:#fff}
  #tune{display:none;margin-top:22px;border-top:1px solid #333;padding-top:14px;text-align:left}
  #tune h3{text-align:center;color:#2d7dff;margin:6px 0 12px}
  .row{display:flex;justify-content:space-between;align-items:center;margin:8px 0;gap:8px}
  .row label{flex:1;color:#ccc}
  .row input{width:110px;padding:8px;font-size:16px;border-radius:8px;border:1px solid #444;background:#222;color:#fff;text-align:right}
  .row select{padding:8px;border-radius:8px;border:1px solid #444;background:#222;color:#fff}
  .apply{width:100%;padding:13px;margin-top:12px;font-size:17px;border:none;border-radius:10px;background:#2d7dff;color:#fff}
  .scanbtn{width:100%;padding:12px;margin-top:10px;font-size:16px;border:none;border-radius:10px;background:#3a3;color:#fff}
  .smallbtn{padding:8px 12px;font-size:14px;border:none;border-radius:8px;background:#2d7dff;color:#fff}
</style>
</head>
<body>
<h2>电机控制</h2>
<div class="modes">
  <button id="b0" onclick="setMode(0)">停止</button>
  <button id="b1" onclick="setMode(1)">速度</button>
  <button id="b2" onclick="setMode(2)">角度</button>
</div>
<div class="val" id="disp">--</div>
<div class="actual" id="actual">实际: -- RPM</div>
<input type="range" id="slider" min="-120" max="120" step="1" value="0" oninput="onSlide()">
<div class="hint" id="hint">拖动滑块调节转速</div>
<div class="lim">限幅(电流/电压) <input id="lim" type="number" step="100"> <button onclick="setLim()">设置</button></div>
<div class="lim"><button onclick="zeroHere()">复位(设零): 当前方向 = 0°</button></div>

<div id="tune">
  <h3>调参 (停止状态可改)</h3>
  __TUNE_ROWS__
  <button class="apply" onclick="apply()">应用参数</button>

  <h3 style="margin-top:20px">电机识别</h3>
  <div class="hint" style="text-align:center">当前: <span id="curmotor">--</span></div>
  <button class="scanbtn" onclick="doScan()">扫描电机</button>
  <div id="scanres" class="hint" style="text-align:center;margin-top:8px"></div>
</div>

<script>
const MAX_RPM = __MAX_RPM__, MAX_ANGLE = __MAX_ANGLE__, LIM_ID = __LIM_ID__;
const PARAMS = [__JS_PARAMS__];
const TYPES = ["GM6020","M3508","M2006"];
let mode = 1, filled = false, scan_ids = [];
function cfg(m){
  if(m===1) return {min:-MAX_RPM,max:MAX_RPM,unit:' RPM',scale:1};
  if(m===2) return {min:-MAX_ANGLE,max:MAX_ANGLE,unit:' deg',scale:10};
  return {min:-MAX_RPM,max:MAX_RPM,unit:'',scale:1};
}
function setMode(m){
  mode = m;
  const c = cfg(m);
  const s = document.getElementById('slider');
  s.min=c.min; s.max=c.max; s.value=0;
  document.getElementById('b0').className = (m===0)?'on':'';
  document.getElementById('b1').className = (m===1)?'on':'';
  document.getElementById('b2').className = (m===2)?'on':'';
  document.getElementById('hint').textContent =
      (m===0)?'已停止':(m===1)?'拖动滑块调节转速':'拖动滑块转到固定角度';
  onSlide();
}
function onSlide(){
  const v = parseInt(document.getElementById('slider').value);
  const c = cfg(mode);
  document.getElementById('disp').textContent = (mode===0)?'--':(v + c.unit);
}
let lastSend=0, tmr=null;
function send(){
  const c = cfg(mode);
  const v = parseInt(document.getElementById('slider').value);
  const value = (mode===0)?0:Math.round(v*c.scale);
  const now = Date.now();
  const doFetch = () => { lastSend=Date.now(); fetch('/set?mode='+mode+'&value='+value).catch(()=>{}); };
  if(now-lastSend>80) doFetch();
  else if(!tmr) tmr=setTimeout(()=>{ tmr=null; doFetch(); }, 80-(now-lastSend));
}
function setLim(){
  const v = parseInt(document.getElementById('lim').value);
  fetch('/setp?id='+LIM_ID+'&value='+v).catch(()=>{});
}
function zeroHere(){
  if(confirm('把电机当前方向设为角度模式的 0 度?')) fetch('/zero').catch(()=>{});
}
function fillTune(p){
  PARAMS.forEach((a, i) => {
    const el = document.getElementById('p'+a[0]);
    if(el) el.value = (p[2+i]/a[1]).toFixed(2);
  });
}
function apply(){
  const seq = [];
  for(const [id,scale] of PARAMS){
    const el = document.getElementById('p'+id);
    if(el) seq.push([id, Math.round(parseFloat(el.value)*scale)]);
  }
  let i = 0;
  const next = () => {
    if(i>=seq.length){ alert('参数已下发'); return; }
    const [id,val] = seq[i++];
    fetch('/setp?id='+id+'&value='+val).then(next).catch(next);
  };
  next();
}
function doScan(){
  document.getElementById('scanres').textContent = '扫描中...';
  scan_ids = [];
  fetch('/scan').catch(()=>{});
  setTimeout(loadScanRes, 800);
}
function loadScanRes(){
  fetch('/scanres').then(r=>r.text()).then(t=>{
    scan_ids = t.trim() ? t.trim().split(',').map(Number) : [];
    renderScan();
  }).catch(()=>{});
}
function renderScan(){
  const el = document.getElementById('scanres');
  if(scan_ids.length===0){ el.textContent='未发现电机 (检查供电/CAN 接线)'; return; }
  let h = '';
  scan_ids.forEach(fid => {
    let sug = 0, id = fid - 0x204;
    if(fid>=0x201 && fid<=0x204){ sug = 1; id = fid - 0x200; }  // 可能 M3508/M2006
    else if(fid>=0x205 && fid<=0x208){ sug = 0; id = fid - 0x204; } // 可能 GM6020
    else if(fid>=0x209 && fid<=0x20B){ sug = 0; id = fid - 0x204; }
    h += '<div class="row"><label>0x'+fid.toString(16).toUpperCase()+'</label>'+
         '<select id="t'+fid+'">'+
         TYPES.map((n,k)=>'<option value="'+k+'"'+(k===sug?' selected':'')+'>'+n+'</option>').join('')+
         '</select><input id="i'+fid+'" type="number" min="1" max="8" value="'+id+'" style="width:55px">'+
         '<button class="smallbtn" onclick="applyMotor('+fid+')">应用</button></div>';
  });
  el.innerHTML = h;
}
function applyMotor(fid){
  const t = parseInt(document.getElementById('t'+fid).value);
  const id = parseInt(document.getElementById('i'+fid).value);
  fetch('/settype?type='+t+'&id='+id).then(()=>{ alert('已设置: '+TYPES[t]+' ID'+id); }).catch(()=>{});
}
function pollState(){
  fetch('/state').then(r=>r.text()).then(t=>{
    const p = t.split(',').map(Number);
    if(p.length >= __FBLEN__){
      const m = p[0], rpm = p[1];
      document.getElementById('actual').textContent = (m===2)?'实际: 角度模式':('实际: '+rpm+' RPM');
      const el = document.getElementById('lim');
      if(document.activeElement !== el) el.value = p[__LIM_IDX__];
      const ty = p[__TYPE_IDX__], mid = p[__ID_IDX__];
      document.getElementById('curmotor').textContent = (TYPES[ty]||'?') + ' ID' + mid;
      const tune = document.getElementById('tune');
      if(m===0){ tune.style.display='block'; if(!filled){ fillTune(p); filled = true; } }
      else { tune.style.display='none'; filled = false; }
    }
  }).catch(()=>{});
}
setMode(1);
setInterval(send, 250);
setInterval(pollState, 400);
</script>
</body>
</html>
"""
PAGE = (PAGE
        .replace("__TUNE_ROWS__", _tune_rows)
        .replace("__JS_PARAMS__", _js_params)
        .replace("__MAX_RPM__", str(MAX_RPM))
        .replace("__MAX_ANGLE__", str(MAX_ANGLE))
        .replace("__LIM_ID__", str(LIMIT_ID))
        .replace("__LIM_IDX__", str(LIM_IDX))
        .replace("__TYPE_IDX__", str(TYPE_IDX))
        .replace("__ID_IDX__", str(ID_IDX))
        .replace("__FBLEN__", str(STATE_LEN)))


def send_all(sock, data):
    mv = memoryview(data)
    while len(mv):
        n = sock.send(mv)
        if n is None:
            break
        mv = mv[n:]


def http_ok(cl, content_type, body):
    hdr = ("HTTP/1.1 200 OK\r\nContent-Type: %s\r\n"
           "Content-Length: %d\r\nConnection: close\r\n\r\n") % (content_type, len(body))
    send_all(cl, hdr.encode())
    send_all(cl, body)


def parse_query(path):
    q = {}
    if "?" in path:
        for kv in path.split("?", 1)[1].split("&"):
            if "=" in kv:
                k, v = kv.split("=", 1)
                q[k] = v
    return q


uart = UART(UART_ID, baudrate=BAUD, tx=UART_TX, rx=UART_RX)

ap = network.WLAN(network.AP_IF)
ap.active(True)
ap.config(essid=AP_SSID, password=AP_PASS, max_clients=4)
while not ap.active():
    time.sleep_ms(50)
print("AP ready:", ap.ifconfig()[0])

srv = socket.socket()
srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
srv.bind(socket.getaddrinfo("0.0.0.0", 80)[0][-1])
srv.listen(4)
srv.settimeout(0.05)

mode = 0
value = 0
last_http = time.ticks_ms()
state = [0] * STATE_LEN
scan_ids = []
rxbuf = b""
last_cmd = time.ticks_ms()
last_saved = None
last_save_ms = 0


def load_cfg():
    try:
        with open(CFG_FILE) as f:
            vals = [int(x) for x in f.read().strip().split(",")]
        if len(vals) == len(CFG_IDS):
            for pid, v in zip(CFG_IDS, vals):
                uart.write("P,%d,%d\n" % (pid, v))
                time.sleep_ms(30)
            print("cfg restored:", vals)
    except Exception as e:
        print("cfg load:", e)


def save_cfg():
    try:
        vals = [state[IDX[i]] for i in CFG_IDS]
        with open(CFG_FILE, "w") as f:
            f.write(",".join(str(v) for v in vals))
        print("cfg saved:", vals)
    except Exception as e:
        print("cfg save:", e)


print("HTTP server listening on :80")
time.sleep_ms(300)
load_cfg()


def send_cmd():
    try:
        uart.write("C,%d,%d\n" % (mode, value))
    except Exception:
        pass


while True:
    while True:
        try:
            cl, _ = srv.accept()
        except OSError:
            break
        try:
            cl.settimeout(0.3)
            req = cl.recv(512).decode()
            path = req.split(" ", 2)[1] if " " in req else "/"
            if path.startswith("/setp"):
                q = parse_query(path)
                if "id" in q and "value" in q:
                    uart.write("P,%s,%s\n" % (q["id"], q["value"]))
                http_ok(cl, "text/plain", b"ok")
            elif path.startswith("/settype"):
                q = parse_query(path)
                if "type" in q and "id" in q:
                    uart.write("M,%s,%s\n" % (q["type"], q["id"]))
                http_ok(cl, "text/plain", b"ok")
            elif path.startswith("/scanres"):
                http_ok(cl, "text/plain", ",".join(str(x) for x in scan_ids).encode())
            elif path.startswith("/scan"):
                uart.write("S\n")
                http_ok(cl, "text/plain", b"ok")
            elif path.startswith("/zero"):
                uart.write("Z\n")
                http_ok(cl, "text/plain", b"ok")
            elif path.startswith("/set"):
                q = parse_query(path)
                if "mode" in q:
                    mode = int(q["mode"])
                if "value" in q:
                    value = int(q["value"])
                last_http = time.ticks_ms()
                send_cmd()
                http_ok(cl, "text/plain", b"ok")
            elif path.startswith("/state"):
                http_ok(cl, "text/plain", ",".join(str(x) for x in state).encode())
            elif path.startswith("/favicon"):
                http_ok(cl, "image/x-icon", b"")
            else:
                http_ok(cl, "text/html; charset=utf-8", PAGE.encode())
        except Exception as e:
            print("http err:", e)
        finally:
            try:
                cl.close()
            except Exception:
                pass

    try:
        rx = uart.read()
        if rx:
            rxbuf += rx
            while b"\n" in rxbuf:
                line, rxbuf = rxbuf.split(b"\n", 1)
                line = line.strip()
                if line.startswith(b"F,"):
                    p = line.decode().split(",")
                    if len(p) >= STATE_LEN + 1:
                        state = [int(x) for x in p[1:1 + STATE_LEN]]
                elif line.startswith(b"S,"):
                    p = line.decode().split(",")
                    if len(p) >= 2:
                        n = int(p[1])
                        scan_ids = [int(x) for x in p[2:2 + n]]
    except Exception:
        pass

    now = time.ticks_ms()
    if time.ticks_diff(now, last_http) > 1500:
        mode = 0
        value = 0

    if state[0] == 0 and state != last_saved and time.ticks_diff(now, last_save_ms) > 1000:
        last_save_ms = now
        last_saved = list(state)
        save_cfg()

    if time.ticks_diff(now, last_cmd) >= 200:
        last_cmd = now
        send_cmd()

    time.sleep_ms(10)
